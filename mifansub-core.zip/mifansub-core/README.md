# 🦊 MiFansub Core

Plataforma Full-Stack de gestión de proyectos, automatización y seguimiento de progreso para grupos de fansub (anime, hentai, manga, manhwa, películas y series).

## Estructura del repositorio

```
mifansub-core/
├── web/     -> Panel administrativo (Next.js 14 App Router + Tailwind CSS + Supabase + NextAuth)
├── bot/     -> Bot de Discord (discord.js v14) con comandos /progreso /status /done y botones
└── docs/
    └── GUIA_INSTALACION.md -> Guía paso a paso para desplegar todo (Supabase, Discord, Vercel/Netlify, Railway/Koyeb)
```

## Empezá acá

👉 Abrí **`docs/GUIA_INSTALACION.md`** y seguí los pasos en orden. En ~30-45 minutos vas a tener:

1. La base de datos en Supabase
2. La aplicación de Discord (login + bot)
3. El panel web en producción (Vercel o Netlify)
4. El bot corriendo 24/7 (Railway o Koyeb)

## Componentes

- **Panel Web**: login con Discord OAuth2 (solo staff autorizado), catálogo de series con barras de progreso, vistas filtradas por tipo de contenido, formulario de alta de series, gestión de staff, generador de snippets de iFrame.
- **Widget iFrame**: ruta pública `/embed/[slug]` para incrustar en WordPress u otro CMS.
- **Bot de Discord**: un embed persistente por serie que se edita in-place (sin spam) desde comandos `/` o botones táctiles.
- **Diseño**: Tailwind CSS, tema Cyber-Glassmorphism (paneles translúcidos, blur, barras neón cian/magenta/verde) con soporte de tema claro/oscuro y diseño responsivo (sidebar → menú hamburguesa en móvil).

## Proyectos de referencia utilizados para el diseño

- [naoTimesdev/naoTimes](https://github.com/naoTimesdev) — ecosistema de bot de Discord para fansubs
- [naoTimesdev/showtimes](https://github.com/naoTimesdev/showtimes) — backend GraphQL que separa la lógica de datos del bot y la web
- [naoTimesdev/ui](https://github.com/naoTimesdev/ui) — frontend del panel (naoTimesUI)
- `panel.naoti.me` — panel web público de referencia
