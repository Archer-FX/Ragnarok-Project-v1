const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const { supabase } = require("../lib/supabase");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("status")
    .setDescription("Muestra el estado general de todas las series en producción"),

  async execute(interaction) {
    await interaction.deferReply();

    const { data: proyectos, error } = await supabase
      .from("proyectos")
      .select("titulo, estado, progreso_tl, progreso_cr, progreso_sinc")
      .eq("estado", "TRABAJANDO")
      .order("created_at", { ascending: false });

    if (error) return interaction.editReply("Error consultando la base de datos.");
    if (!proyectos?.length) return interaction.editReply("No hay series en producción por ahora.");

    const embed = new EmbedBuilder()
      .setTitle("📊 Series en producción")
      .setColor(0x22d3ee)
      .setDescription(
        proyectos
          .map(
            (p) =>
              `**${p.titulo}** — TL ${p.progreso_tl}% · CR ${p.progreso_cr}% · SINC ${p.progreso_sinc}%`
          )
          .join("\n")
      );

    await interaction.editReply({ embeds: [embed] });
  },
};
