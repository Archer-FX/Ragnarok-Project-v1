const { SlashCommandBuilder } = require("discord.js");
const { supabase } = require("../lib/supabase");
const { construirEmbedProyecto } = require("../lib/embedBuilder");
const { refrescarEmbedEnCanal } = require("../lib/refrescarEmbed");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("done")
    .setDescription("Marca una fase como 100% completada para una serie")
    .addStringOption((opt) =>
      opt.setName("slug").setDescription("Slug de la serie").setRequired(true)
    )
    .addStringOption((opt) =>
      opt
        .setName("fase")
        .setDescription("Fase a marcar como completa")
        .setRequired(true)
        .addChoices(
          { name: "Traducción (TL)", value: "progreso_tl" },
          { name: "Corrección (CR)", value: "progreso_cr" },
          { name: "Sincronía (SINC)", value: "progreso_sinc" },
          { name: "Control de Calidad (QC)", value: "progreso_qc" }
        )
    ),

  async execute(interaction, client) {
    const slug = interaction.options.getString("slug");
    const fase = interaction.options.getString("fase");
    await interaction.deferReply({ ephemeral: true });

    const { data: proyecto, error } = await supabase
      .from("proyectos")
      .update({ [fase]: 100 })
      .eq("slug", slug)
      .select()
      .single();

    if (error || !proyecto) {
      return interaction.editReply("No pude actualizar esa serie. Revisá el slug.");
    }

    await refrescarEmbedEnCanal(client, proyecto);
    await interaction.editReply(`✅ ${fase.replace("progreso_", "").toUpperCase()} marcado como 100% en "${proyecto.titulo}".`);
  },
};
