const { SlashCommandBuilder } = require("discord.js");
const { supabase } = require("../lib/supabase");
const { construirEmbedProyecto } = require("../lib/embedBuilder");

module.exports = {
  data: new SlashCommandBuilder()
    .setName("progreso")
    .setDescription("Publica o refresca la tarjeta de progreso de una serie en este canal")
    .addStringOption((opt) =>
      opt.setName("slug").setDescription("Slug de la serie (ej: naruto-shippuden-abc123)").setRequired(true)
    ),

  async execute(interaction) {
    const slug = interaction.options.getString("slug");
    await interaction.deferReply({ ephemeral: true });

    const { data: proyecto, error } = await supabase
      .from("proyectos")
      .select("*, asignaciones(fase_asignada, staff:staff_id(username))")
      .eq("slug", slug)
      .single();

    if (error || !proyecto) {
      return interaction.editReply(`No encontré ninguna serie con el slug \`${slug}\`.`);
    }

    const payload = construirEmbedProyecto(proyecto, proyecto.asignaciones ?? []);
    const mensaje = await interaction.channel.send(payload);

    await supabase
      .from("proyectos")
      .update({
        discord_canal_id: interaction.channel.id,
        discord_mensaje_id: mensaje.id,
      })
      .eq("id", proyecto.id);

    await interaction.editReply(`✅ Tarjeta de "${proyecto.titulo}" publicada y enlazada a este canal.`);
  },
};
