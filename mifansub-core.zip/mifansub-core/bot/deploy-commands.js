require("dotenv").config();
const { REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

const commands = [];
const commandsPath = path.join(__dirname, "commands");
const commandFiles = fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  commands.push(command.data.toJSON());
}

const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_BOT_TOKEN);

(async () => {
  try {
    console.log(`Registrando ${commands.length} comandos: ${commands.map((c) => c.name).join(", ")}`);

    if (process.env.DISCORD_GUILD_ID) {
      // Comandos "de guild": aparecen al instante, ideal mientras desarrollás.
      await rest.put(
        Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID, process.env.DISCORD_GUILD_ID),
        { body: commands }
      );
      console.log("✅ Comandos registrados en el servidor (instantáneo).");
    } else {
      // Comandos globales: tardan hasta ~1 hora en propagarse a todos los servidores.
      await rest.put(Routes.applicationCommands(process.env.DISCORD_CLIENT_ID), { body: commands });
      console.log("✅ Comandos registrados globalmente (puede tardar hasta 1 hora).");
    }
  } catch (err) {
    console.error(err);
  }
})();
