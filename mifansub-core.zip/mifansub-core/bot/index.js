require("dotenv").config();
const fs = require("fs");
const path = require("path");
const { Client, GatewayIntentBits, Collection } = require("discord.js");
const { supabase } = require("./lib/supabase");
const { refrescarEmbedEnCanal } = require("./lib/refrescarEmbed");

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages],
});

// --- Carga dinámica de comandos (commands/*.js) ---
client.commands = new Collection();
const commandsPath = path.join(__dirname, "commands");
for (const file of fs.readdirSync(commandsPath).filter((f) => f.endsWith(".js"))) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

client.once("ready", () => {
  console.log(`🦊 MiFansub Core Bot conectado como ${client.user.tag}`);
});

client.on("interactionCreate", async (interaction) => {
  try {
    // --- Slash commands ---
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);
      if (!command) return;
      await command.execute(interaction, client);
      return;
    }

    // --- Botones del Embed (+10% TL, +10% CR, +10% SINC, Editar) ---
    if (interaction.isButton()) {
      const [prefijo, accion, proyectoId] = interaction.customId.split(":");
      if (prefijo !== "mfc") return;

      if (accion === "editar") {
        await interaction.reply({
          content: "Editá el progreso completo desde el panel web (más opciones que los botones rápidos).",
          ephemeral: true,
        });
        return;
      }

      const CAMPO_POR_ACCION = {
        tl10: "progreso_tl",
        cr10: "progreso_cr",
        sinc10: "progreso_sinc",
      };
      const campo = CAMPO_POR_ACCION[accion];
      if (!campo) return;

      await interaction.deferUpdate();

      const { data: actual } = await supabase
        .from("proyectos")
        .select(campo)
        .eq("id", proyectoId)
        .single();

      const nuevoValor = Math.min(100, (actual?.[campo] ?? 0) + 10);

      await supabase.from("proyectos").update({ [campo]: nuevoValor }).eq("id", proyectoId);

      await refrescarEmbedEnCanal(client, proyectoId);
    }
  } catch (err) {
    console.error("Error manejando interacción:", err);
  }
});

client.login(process.env.DISCORD_BOT_TOKEN);
