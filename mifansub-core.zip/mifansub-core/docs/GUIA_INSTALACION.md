# 🦊 MiFansub Core — Guía de instalación paso a paso

Esta guía te lleva desde cero hasta tener el panel web, la base de datos y el bot de Discord funcionando en producción. Seguí los pasos en orden: **1) Supabase → 2) Discord App → 3) Panel Web (Vercel o Netlify) → 4) Bot de Discord**.

---

## 1. Crear y configurar la base de datos (Supabase)

1. Entrá a [supabase.com](https://supabase.com) y creá una cuenta gratuita.
2. Botón **New Project**. Elegí un nombre, una contraseña de base de datos (guardala) y una región cercana a tu audiencia.
3. Esperá ~2 minutos a que se aprovisione el proyecto.
4. En el menú lateral andá a **SQL Editor → New query**.
5. Abrí el archivo `web/supabase/schema.sql` de este proyecto, copiá **todo** su contenido, pegalo en el editor y apretá **Run**. Esto crea todas las tablas (`proyectos`, `staff`, `asignaciones`, `admins_permitidos`, `ajustes`, `logs_auditoria`, `trials_pendientes`) con seguridad a nivel de fila (RLS) ya configurada.
6. Andá a **Project Settings → API**. Ahí vas a encontrar tres datos que necesitás guardar para más adelante:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **anon public key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **service_role key** (botón "Reveal") → `SUPABASE_SERVICE_ROLE_KEY` — **nunca la publiques ni la subas a GitHub**, es la llave maestra.
7. Ejecutá esta consulta en el SQL Editor para autorizarte a vos mismo a entrar al panel (reemplazá el ID por tu Discord ID; para conseguirlo, activá el Modo Desarrollador en Discord: `Ajustes → Avanzado → Modo Desarrollador`, luego clic derecho en tu nombre → **Copiar ID de usuario**):

```sql
insert into admins_permitidos (discord_id, nota)
values ('TU_DISCORD_ID_AQUI', 'Fundador');
```

---

## 2. Crear la aplicación de Discord (una sola app sirve para el login web y el bot)

1. Andá a [discord.com/developers/applications](https://discord.com/developers/applications) → **New Application**. Nombrala, por ejemplo, "MiFansub Core".
2. En **General Information** copiá el **Application ID** → es tu `DISCORD_CLIENT_ID`.
3. Andá a **OAuth2 → General**:
   - Copiá el **Client Secret** → `DISCORD_CLIENT_SECRET`.
   - En **Redirects**, agregá (lo vas a ajustar con la URL real una vez desplegado, pero podés dejarlo cargado ahora con un placeholder y editarlo después):
     ```
     https://tu-panel.vercel.app/api/auth/callback/discord
     ```
     o si usás Netlify:
     ```
     https://tu-panel.netlify.app/api/auth/callback/discord
     ```
4. Andá a **Bot** (menú lateral):
   - Botón **Reset Token** → copiá el token → `DISCORD_BOT_TOKEN` (guardalo, no se vuelve a mostrar).
   - Activá **Message Content Intent** si pensás leer contenido de mensajes en el futuro (no es obligatorio para los comandos `/`).
5. Andá a **OAuth2 → URL Generator**:
   - Marcá el scope `bot` y `applications.commands`.
   - En permisos del bot marcá: `Send Messages`, `Embed Links`, `Read Message History`, `Use Slash Commands`.
   - Copiá la URL generada al final, abrila en el navegador y elegí tu servidor para invitar al bot.
6. En tu servidor de Discord, activá el Modo Desarrollador (si no lo hiciste), clic derecho sobre el servidor → **Copiar ID del servidor** → `DISCORD_GUILD_ID`. Clic derecho sobre el canal donde querés el tracking (ej: `#progreso-temporada`) → **Copiar ID del canal** → `DISCORD_CANAL_PROGRESO_ID`.

---

## 3. Desplegar el Panel Web

Podés elegir **Vercel** (recomendado para Next.js, cero configuración extra) o **Netlify** (también soportado). Elegí una sola opción.

### Opción A — Vercel

1. Subí la carpeta `web/` a un repositorio de GitHub (podés crear un repo nuevo y subir todo el proyecto `mifansub-core`, Vercel te va a dejar elegir la subcarpeta).
2. Entrá a [vercel.com](https://vercel.com) → **Add New → Project** → importá tu repositorio.
3. En **Root Directory**, seleccioná `web` (si subiste todo el monorepo) o dejalo en blanco si el repo es solo el contenido de `web/`.
4. Framework Preset: Vercel detecta **Next.js** automáticamente.
5. En **Environment Variables**, cargá todas las que están en `web/.env.example`:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `DISCORD_CLIENT_ID`
   - `DISCORD_CLIENT_SECRET`
   - `NEXTAUTH_SECRET` (generalo corriendo `openssl rand -base64 32` en tu terminal, o usá cualquier generador de cadenas aleatorias online)
   - `NEXTAUTH_URL` → dejalo como `https://placeholder.vercel.app` por ahora, lo vas a corregir en el paso 7.
6. Clic en **Deploy**. Esperá 1-2 minutos.
7. Una vez desplegado, Vercel te da tu URL real (ej: `https://mifansub-core.vercel.app`). Andá a **Project Settings → Environment Variables** y actualizá `NEXTAUTH_URL` con esa URL exacta (sin barra final). Volvé a **Deployments** y hacé **Redeploy** para que tome el cambio.
8. Volvé al Discord Developer Portal → tu app → **OAuth2 → Redirects** y actualizá la URL de redirect con tu dominio real:
   ```
   https://mifansub-core.vercel.app/api/auth/callback/discord
   ```
9. Entrá a tu panel, clic en **Iniciar sesión con Discord**. Si tu Discord ID está en `admins_permitidos`, vas a entrar directo al catálogo de proyectos.

### Opción B — Netlify

1. Subí el proyecto a GitHub igual que en la Opción A.
2. Entrá a [app.netlify.com](https://app.netlify.com) → **Add new site → Import an existing project**.
3. Elegí tu repositorio. En **Base directory** poné `web`.
4. Netlify detecta Next.js automáticamente vía el plugin `@netlify/plugin-nextjs` (se instala solo). Build command: `npm run build`. Publish directory: se completa solo.
5. En **Site configuration → Environment variables**, cargá las mismas variables que en el paso 5 de la Opción A.
6. Deploy. Cuando tengas tu URL (ej: `https://mifansub-core.netlify.app`), repetí los pasos 7 y 8 de la Opción A (actualizar `NEXTAUTH_URL` y el Redirect de Discord) pero con tu dominio de Netlify.

> **Nota:** Next.js App Router con Server Actions y rutas dinámicas funciona en ambas plataformas. Si en algún momento ves un error de "Server Actions" en Netlify, revisá que el plugin de Next.js esté activo en **Site configuration → Build & deploy → Plugins**.

---

## 4. Desplegar el Bot de Discord (necesita correr 24/7, por eso va aparte del panel)

Los proveedores serverless de Vercel/Netlify apagan el proceso entre pedidos, así que el bot **no puede vivir ahí**: necesita un proceso siempre encendido. Usá **Railway** o **Koyeb** (ambos tienen plan gratuito/económico).

### Opción A — Railway

1. Subí la carpeta `bot/` a GitHub (puede ser el mismo repo, en su propia carpeta).
2. Entrá a [railway.app](https://railway.app) → **New Project → Deploy from GitHub repo**.
3. Elegí el repositorio. En **Settings → Root Directory** poné `bot`.
4. En **Variables**, cargá todo lo de `bot/.env.example`:
   - `DISCORD_BOT_TOKEN`
   - `DISCORD_CLIENT_ID`
   - `DISCORD_GUILD_ID`
   - `DISCORD_CANAL_PROGRESO_ID`
   - `SUPABASE_URL`
   - `SUPABASE_SERVICE_ROLE_KEY`
5. En **Settings → Deploy**, definí el **Start Command** como `npm start` (o dejalo, Railway detecta `package.json`).
6. Antes del primer arranque necesitás registrar los comandos `/` una sola vez. En Railway podés abrir una terminal del servicio (o correrlo localmente apuntando a las mismas variables) y ejecutar:
   ```bash
   npm install
   npm run deploy-commands
   ```
   Esto sólo hace falta repetirlo si agregás o cambiás comandos en el futuro.
7. Iniciá el servicio. En los logs deberías ver `🦊 MiFansub Core Bot conectado como TuBot#0000`.

### Opción B — Koyeb

1. Entrá a [koyeb.com](https://koyeb.com) → **Create App → GitHub**.
2. Elegí el repo y la carpeta `bot` como directorio de trabajo (Working directory).
3. Build: Koyeb detecta Node.js automáticamente (usa `npm install` y `npm start`).
4. Cargá las mismas variables de entorno del paso 4 de Railway en **Environment variables**.
5. Antes de desplegar (o desde tu máquina local con un `.env` temporal), corré una vez:
   ```bash
   npm install
   npm run deploy-commands
   ```
6. Desplegá. Revisá los logs para confirmar la conexión.

---

## 5. Probar todo el flujo de punta a punta

1. En tu servidor de Discord, en el canal que elegiste, escribí `/progreso slug:el-slug-de-tu-serie` (el slug se genera solo al crear la serie desde el panel web, lo ves en la URL de "Editar" o en el botón "Copiar iFrame").
2. Debería aparecer la tarjeta con las barras de progreso y los botones `+10% TL`, `+10% CR`, `+10% SINC`.
3. Tocá un botón: el mensaje se debería actualizar in-place (sin crear uno nuevo).
4. Andá al panel web → editá esa misma serie → cambiá algún porcentaje → Guardar. Volvé a Discord: si corrés `/progreso` de nuevo vas a ver el valor actualizado (el refresco automático en vivo del embed sin comando adicional es una mejora a futuro; por ahora el bot refresca el embed cuando el cambio viene desde sus propios botones o comandos).
5. Copiá el snippet de iFrame de una serie desde el panel (botón "Copiar iFrame") y pegalo en un bloque HTML personalizado de WordPress:
   ```html
   <iframe src="https://tu-panel.vercel.app/embed/el-slug" width="100%" height="320px" frameborder="0" scrolling="no"></iframe>
   ```

---

## 6. Variables de entorno — resumen rápido

**Proyecto web** (`web/.env.local` en local, o variables del hosting):
```
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
DISCORD_CLIENT_ID=
DISCORD_CLIENT_SECRET=
NEXTAUTH_SECRET=
NEXTAUTH_URL=
```

**Bot de Discord** (`bot/.env` en local, o variables del hosting):
```
DISCORD_BOT_TOKEN=
DISCORD_CLIENT_ID=
DISCORD_GUILD_ID=
DISCORD_CANAL_PROGRESO_ID=
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
```

---

## 7. Correrlo en tu computadora (opcional, para probar antes de desplegar)

Necesitás [Node.js 18+](https://nodejs.org) instalado.

```bash
# Panel web
cd web
npm install
cp .env.example .env.local   # completá los valores
npm run dev                   # abre en http://localhost:3000

# Bot de Discord (en otra terminal)
cd bot
npm install
cp .env.example .env          # completá los valores
npm run deploy-commands       # sólo la primera vez o al cambiar comandos
npm start
```

---

## 8. Próximos pasos sugeridos (funciones avanzadas ya contempladas en la base de datos)

El esquema SQL ya incluye las tablas para estas funciones del documento original; la interfaz de cada una es la siguiente extensión natural del panel:

- **Semáforo de Burnout**: calcular minutos/capítulos asignados por semana desde `asignaciones` y mostrar 🟢/🟡/🔴 en la página de Staff.
- **Modo AFK**: ya existen `estado_afk`, `afk_desde`, `afk_hasta` en `staff`; falta el switch en la UI y el aviso automático del bot.
- **Solicitud de suplencias**: un botón que dispare un mensaje de Discord (webhook) tageando a `especialidades` coincidentes.
- **Trials/Aprendices**: la tabla `trials_pendientes` ya está lista para que un mentor apruebe antes de que el cambio impacte en `proyectos`.
- **Logs de auditoría y "deshacer"**: `logs_auditoria` está creada; falta registrar cada cambio desde las Server Actions y agregar el botón de undo.

Si querés, en la próxima etapa seguimos con cualquiera de estos módulos.
